WILDLIFE SA RESCUE SYSTEM - JAVA WITH ANT
=========================================

Open the WildLifeSARescueSystem_Ant folder using File > Open Project in NetBeans.
Use JDK 17 or later. The folder contains build.xml and nbproject/project.xml.
Run wildlifesa.Main to use the console menu. Case data is stored in memory
until the application closes.

With Apache Ant installed, these commands are available:
    ant compile
    ant test
    ant run
    ant jar

Tests use JUnit 4 annotations and assertions. The bundled JUnit Platform
standalone JAR contains the JUnit 4 API and Vintage engine, so `ant test` runs
them without another download. The test suite verifies all three cost rules,
priority branches, status changes, search, duplicate IDs, validation and report
totals. It does not require JUnit 5 test syntax.

RescueStatus permits only RECORDED, IN PROGRESS and COMPLETED. The numbered
status menu does not accept arbitrary text. The ArrayList holds all three
RescueCase subclasses, while the interface defines common rescue operations.
The report uses aligned columns and totals.

Priority rules chosen because the brief does not prescribe an exact scale:
- Injured: CRITICAL when surgery is required, otherwise HIGH.
- Orphaned: HIGH for age 6 months or younger or foster care, otherwise MEDIUM.
- Endangered: CRITICAL when a specialist team is needed or classification is
  Critically Endangered, otherwise HIGH.

Academic integrity: Prepared with AI assistance. Review and understand the
code, adapt it yourself, and follow your institution's individual assignment
and AI disclosure rules. A particular mark cannot be guaranteed.
