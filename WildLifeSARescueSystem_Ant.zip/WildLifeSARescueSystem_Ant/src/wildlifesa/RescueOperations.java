package wildlifesa;

public interface RescueOperations {
    void startRescueOperation();
    void completeRescueOperation();
    String generateRescueSummary();
}
